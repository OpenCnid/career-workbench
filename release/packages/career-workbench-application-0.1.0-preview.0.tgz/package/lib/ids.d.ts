import type { EntityId, UtcTimestamp, WorkspaceId } from "@career-workbench/domain";
export interface Clock {
    now(): UtcTimestamp;
}
export interface IdFactory {
    entity(prefix: string): EntityId;
    workspace(): WorkspaceId;
}
export declare class SystemClock implements Clock {
    now(): UtcTimestamp;
}
export declare class RandomIdFactory implements IdFactory {
    entity(prefix: string): EntityId;
    workspace(): WorkspaceId;
}
export declare class DeterministicIdFactory implements IdFactory {
    private readonly seed;
    private nextValue;
    constructor(seed?: string);
    private next;
    entity(prefix: string): EntityId;
    workspace(): WorkspaceId;
}
export declare class FixedClock implements Clock {
    private readonly timestamp;
    constructor(timestamp: UtcTimestamp);
    now(): UtcTimestamp;
}
//# sourceMappingURL=ids.d.ts.map