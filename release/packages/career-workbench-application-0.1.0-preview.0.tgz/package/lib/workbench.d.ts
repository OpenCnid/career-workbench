import { type Application, type Approval, type ApprovalEffectKind, type Artifact, type CommandContext, type Comparison, type DiscoveryLead, type DimensionInput, type EntityId, type Evaluation, type EvidenceClassification, type EvidenceItem, type FactConfirmationOutcome, type Digest, type ImportManifest, type ImportMappingRecord, type LegitimacyStatus, type Opportunity, type Operation, type OperationRoute, type OperationState, type ProfileFact, type ProposedBy, type Rubric, type RubricDimension, type SearchProfile, type SearchSeniority, type SourceDocument, type SourceKind, type SourceStatus, type SourceLocator, type TrustClass, type Workspace, type WorkspaceId, type WorkArrangement } from "@career-workbench/domain";
import type { Clock, IdFactory } from "./ids.js";
import type { ArtifactRepository, WorkspaceRepository } from "./ports.js";
export interface CreateWorkspaceInput {
    readonly displayName: string;
    readonly candidateName?: string;
    readonly targetRole?: string;
    readonly targetPriorities?: string;
    readonly locationPreference?: string;
    readonly deferTargetPreferences?: boolean;
    readonly rubricPreset?: "balanced_fit";
    readonly locale: string;
    readonly timezone: string;
}
export interface CaptureSourceInput {
    readonly kind: SourceKind;
    readonly trustClass: TrustClass;
    readonly mediaType: string;
    readonly text: string;
    readonly originalLocator?: string;
}
export interface ProposeFactInput {
    readonly factType: string;
    readonly subject: string;
    readonly predicate: string;
    readonly value: ProfileFact["value"];
    readonly sourceLocators: readonly SourceLocator[];
    readonly proposedBy: ProposedBy;
}
export interface AddCareerHistoryEntryInput {
    readonly personName: string;
    readonly roleTitle: string;
    readonly organization: string;
    readonly dateRange: string;
    readonly achievements: readonly string[];
}
export interface CaptureOpportunityInput {
    readonly sourceDocumentId: EntityId;
    readonly organization: string;
    readonly roleTitle: string;
    readonly originalUrl?: string;
    readonly location?: string;
    readonly workArrangement?: string;
    readonly advertisedCompensation?: string;
    readonly requisitionId?: string;
}
export interface UpsertSearchProfileInput {
    readonly expectedRevision?: number;
    readonly targetRoles: readonly string[];
    readonly seniority: readonly SearchSeniority[];
    readonly locations: readonly string[];
    readonly workArrangements: readonly WorkArrangement[];
    readonly minimumCompensation?: number;
    readonly compensationCurrency?: string;
    readonly aiFocus?: string;
    readonly priorities: readonly string[];
    readonly exclusions: readonly string[];
    readonly active: boolean;
}
export interface RecordDiscoveryLeadInput {
    readonly organization: string;
    readonly roleTitle: string;
    readonly originalUrl: string;
    readonly postingText: string;
    readonly location?: string;
    readonly workArrangement?: string;
    readonly advertisedCompensation?: string;
    readonly requisitionId?: string;
    readonly whyFound: readonly string[];
    readonly matchedCriteria: readonly string[];
    readonly gaps: readonly string[];
    readonly risks: readonly string[];
}
export interface TriageDiscoveryLeadInput {
    readonly expectedRevision: number;
    readonly decision: "new" | "shortlisted" | "dismissed";
    readonly note?: string;
}
export interface TriagedDiscoveryLead {
    readonly lead: DiscoveryLead;
    readonly opportunity: Opportunity | null;
}
export interface ProposeEvidenceInput {
    readonly classification: EvidenceClassification;
    readonly claim: string;
    readonly sourceId?: EntityId;
    readonly locator?: SourceLocator;
    readonly candidateFactId?: EntityId;
    readonly proposedByOperationId?: EntityId;
}
export interface CreateRubricInput {
    readonly semanticVersion: string;
    readonly name: string;
    readonly dimensions: readonly RubricDimension[];
    readonly thresholds: Readonly<Record<string, number>>;
    readonly displayScale: 5 | 100;
}
export interface EvaluateInput {
    readonly opportunityId: EntityId;
    readonly rubricId: EntityId;
    readonly dimensionInputs: readonly DimensionInput[];
    readonly contradictions?: readonly string[];
    readonly operationId?: EntityId;
}
export interface StartOperationInput {
    readonly kind: string;
    readonly inputIdentity: EntityId;
    readonly requestedCapabilities: readonly string[];
    readonly route: Exclude<OperationRoute, "deterministic">;
    readonly dshSessionId: string;
    readonly parentOperationId?: EntityId;
    readonly provider: string;
    readonly model: string;
    readonly reasoningEffort?: string;
    readonly admissionOnly?: boolean;
}
export interface OperationActivityInput {
    readonly expectedRevision: number;
    readonly phase: "started" | "report" | "message" | "followup" | "deleted" | "cell" | "bridge" | "snapshot" | "restore" | "interrupt" | "restart";
    readonly message?: string;
    readonly messageId?: string;
    readonly requestId?: EntityId;
}
export interface TerminalOperationInput {
    readonly expectedRevision: number;
    readonly state: Extract<OperationState, "succeeded" | "failed" | "canceled" | "indeterminate">;
    readonly category: string;
    readonly message: string;
    readonly resultIds: readonly EntityId[];
    readonly artifactIds: readonly EntityId[];
}
export interface CancelOperationInput {
    readonly expectedRevision: number;
    readonly reason: string;
}
export interface RequestChildFollowupInput {
    readonly expectedRevision: number;
    readonly message: string;
}
export interface ComparisonScenarioProposalInput {
    readonly label: string;
    readonly weightsBasisPoints: Readonly<Record<string, number>>;
}
export interface ProposeComparisonInput {
    readonly evaluationIds: readonly EntityId[];
    readonly policyVersion: string;
    readonly scenarios: readonly ComparisonScenarioProposalInput[];
    readonly tradeoffs: readonly string[];
}
export interface CreateApplicationInput {
    readonly opportunityId: EntityId;
    readonly effectiveDate: string;
    readonly note?: string;
}
export interface TransitionApplicationInput {
    readonly expectedRevision: number;
    readonly state: Application["state"];
    readonly effectiveDate: string;
    readonly note?: string;
}
export interface UpdateOpportunitySignalsInput {
    readonly expectedRevision: number;
    readonly sourceStatus: SourceStatus;
    readonly legitimacyStatus: LegitimacyStatus;
}
export type CandidateArtifactKind = "draft_cv" | "draft_cover_letter" | "draft_outreach" | "draft_interview_prep";
export interface CreateCandidateArtifactInput {
    readonly kind: CandidateArtifactKind;
    readonly opportunityId: EntityId;
    readonly factIds: readonly EntityId[];
    readonly styleNote?: string;
}
export interface RequestApprovalInput {
    readonly effectKind: ApprovalEffectKind;
    readonly targetId: EntityId;
    readonly expectedRevision: number;
    readonly expiresInSeconds?: number;
    readonly applicationTransition?: Omit<TransitionApplicationInput, "expectedRevision">;
}
export interface DecideApprovalInput {
    readonly expectedRevision: number;
    readonly decision: "approved" | "denied";
    readonly interactionId: string;
}
export interface ApprovalConsumption {
    readonly approvalId?: EntityId;
    readonly expectedApprovalRevision?: number;
}
export interface CareerOpsImportFileInput {
    readonly relativePath: string;
    readonly mediaType: string;
    readonly kind: SourceKind;
    readonly trustClass: TrustClass;
    readonly bytes: Uint8Array;
    readonly contentDigest: Digest;
}
export interface CareerOpsProfileFactInput {
    readonly sourceRelativePath: string;
    readonly factType: string;
    readonly subject: string;
    readonly predicate: string;
    readonly value: ProfileFact["value"];
    readonly start: number;
    readonly end: number;
    readonly quote: string;
}
export interface CareerOpsApplicationInput {
    readonly sourceRelativePath: string;
    readonly sourceIdentity: string;
    readonly organization: string;
    readonly roleTitle: string;
    readonly originalUrl: string | null;
    readonly location: string | null;
    readonly state: Application["state"];
    readonly effectiveDate: string;
    readonly note: string | null;
    readonly reportRelativePath: string | null;
    readonly originalStatus: string;
    readonly originalScore: string | null;
}
export interface CareerOpsPassiveMappingInput {
    readonly sourceType: ImportMappingRecord["sourceType"];
    readonly sourceIdentity: string;
    readonly sourceRelativePath: string;
    readonly disposition: ImportMappingRecord["disposition"];
    readonly originalStatus: string | null;
    readonly originalScore: string | null;
    readonly note: string | null;
}
export interface ApplyCareerOpsImportInput {
    readonly upstreamRevision: string;
    readonly observedVersion: string | null;
    readonly sourceIdentityDigest: Digest;
    readonly sourceFingerprint: Digest;
    readonly sourceLabel: string;
    readonly files: readonly CareerOpsImportFileInput[];
    readonly profileFacts: readonly CareerOpsProfileFactInput[];
    readonly applications: readonly CareerOpsApplicationInput[];
    readonly passiveMappings: readonly CareerOpsPassiveMappingInput[];
    readonly warnings: readonly string[];
    readonly unsupported: readonly string[];
}
export declare class WorkbenchService {
    readonly workspaceId: WorkspaceId;
    private readonly repository;
    private readonly artifacts;
    private readonly ids;
    private readonly clock;
    constructor(workspaceId: WorkspaceId, repository: WorkspaceRepository, artifacts: ArtifactRepository, ids: IdFactory, clock: Clock);
    initializeWorkspace(input: CreateWorkspaceInput, context: CommandContext): Promise<Workspace>;
    captureSource(input: CaptureSourceInput, context: CommandContext): Promise<SourceDocument>;
    addCareerHistoryEntry(input: AddCareerHistoryEntryInput, context: CommandContext): Promise<{
        readonly source: SourceDocument;
        readonly facts: readonly ProfileFact[];
    }>;
    proposeProfileFact(input: ProposeFactInput, context: CommandContext): Promise<ProfileFact>;
    confirmProfileFact(factId: EntityId, expectedRevision: number, outcome: FactConfirmationOutcome, context: CommandContext): Promise<ProfileFact>;
    upsertSearchProfile(input: UpsertSearchProfileInput, context: CommandContext): Promise<SearchProfile>;
    recordDiscoveryLead(input: RecordDiscoveryLeadInput, context: CommandContext): Promise<DiscoveryLead>;
    triageDiscoveryLead(leadId: EntityId, input: TriageDiscoveryLeadInput, context: CommandContext): Promise<TriagedDiscoveryLead>;
    captureOpportunity(input: CaptureOpportunityInput, context: CommandContext): Promise<Opportunity>;
    proposeEvidence(input: ProposeEvidenceInput, context: CommandContext): Promise<EvidenceItem>;
    decideEvidence(evidenceId: EntityId, expectedRevision: number, decision: "accepted" | "rejected", reason: string, context: CommandContext): Promise<EvidenceItem>;
    private assertRejectedEvidenceNotRevived;
    private isUserCorrectionDescendant;
    createRubric(input: CreateRubricInput, context: CommandContext): Promise<Rubric>;
    evaluate(input: EvaluateInput, context: CommandContext): Promise<Evaluation>;
    startOperation(input: StartOperationInput, context: CommandContext): Promise<Operation>;
    recordOperationActivity(operationId: EntityId, input: OperationActivityInput, context: CommandContext): Promise<Operation>;
    reconcileInterruptedOperations(context: CommandContext): Promise<readonly Operation[]>;
    terminateOperation(operationId: EntityId, input: TerminalOperationInput, context: CommandContext): Promise<Operation>;
    requestOperationCancellation(operationId: EntityId, input: CancelOperationInput, context: CommandContext): Promise<Operation>;
    requestUserOperationCancellation(operationId: EntityId, input: CancelOperationInput, context: CommandContext): Promise<Operation>;
    requestChildFollowup(operationId: EntityId, input: RequestChildFollowupInput, context: CommandContext): Promise<Operation>;
    private authorizeOperation;
    private operationLineageIncludesSession;
    private failOperation;
    sealEvaluationReport(evaluationId: EntityId, context: CommandContext): Promise<Artifact>;
    correctVerifiedFact(factId: EntityId, expectedRevision: number, newValue: ProfileFact["value"], locator: SourceLocator, context: CommandContext): Promise<{
        readonly fact: ProfileFact;
        readonly staleEvaluationIds: readonly EntityId[];
        readonly staleComparisonIds: readonly EntityId[];
        readonly staleArtifactIds: readonly EntityId[];
    }>;
    comparisonProjections(evaluationIds: readonly EntityId[]): Promise<Comparison["evaluationInputs"]>;
    proposeComparison(operationId: EntityId, input: ProposeComparisonInput, context: CommandContext): Promise<Comparison>;
    listApprovals(): Promise<Approval[]>;
    requestApproval(input: RequestApprovalInput, context: CommandContext): Promise<Approval>;
    decideApproval(approvalId: EntityId, input: DecideApprovalInput, context: CommandContext): Promise<Approval>;
    private approvalExpired;
    private expireApproval;
    private requireApprovedEffect;
    acceptComparison(comparisonId: EntityId, expectedRevision: number, context: CommandContext, consumption?: ApprovalConsumption): Promise<Comparison>;
    createApplication(input: CreateApplicationInput, context: CommandContext): Promise<Application>;
    transitionApplication(applicationId: EntityId, input: TransitionApplicationInput, context: CommandContext, consumption?: ApprovalConsumption): Promise<Application>;
    updateOpportunitySignals(opportunityId: EntityId, input: UpdateOpportunitySignalsInput, context: CommandContext): Promise<Opportunity>;
    createCandidateArtifact(input: CreateCandidateArtifactInput, context: CommandContext): Promise<Artifact>;
    reviewCandidateArtifact(artifactId: EntityId, expectedRevision: number, context: CommandContext, consumption?: ApprovalConsumption): Promise<Artifact>;
    readArtifact(artifactId: EntityId): Promise<{
        readonly artifact: Artifact;
        readonly text: string;
    }>;
    applyCareerOpsImport(input: ApplyCareerOpsImportInput, context: CommandContext): Promise<ImportManifest>;
    exportWorkspace(selectedArtifactIds?: readonly EntityId[]): Promise<Readonly<Record<string, unknown>>>;
    private commitInsert;
}
export declare function factClaim(fact: ProfileFact): string;
//# sourceMappingURL=workbench.d.ts.map