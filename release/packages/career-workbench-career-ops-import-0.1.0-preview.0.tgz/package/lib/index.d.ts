import { type ApplyCareerOpsImportInput, type CareerOpsApplicationInput, type CareerOpsPassiveMappingInput } from "@career-workbench/application";
export declare const CAREER_OPS_REVISION: "3a067ee580b7982cf5dd6edf7895112e4e99600b";
export declare const CAREER_OPS_OBSERVED_VERSION: "1.31.0";
export interface CareerOpsPreviewFile {
    readonly relativePath: string;
    readonly mediaType: string;
    readonly byteLength: number;
    readonly contentDigest: string;
    readonly purpose: string;
}
export interface CareerOpsPreviewApplication {
    readonly sourceIdentity: string;
    readonly sourceRelativePath: string;
    readonly organization: string;
    readonly roleTitle: string;
    readonly originalStatus: string;
    readonly mappedState: string;
    readonly originalScore: string | null;
}
export interface CareerOpsImportPreview {
    readonly provider: "career-ops";
    readonly upstreamRevision: typeof CAREER_OPS_REVISION;
    readonly observedVersion: string | null;
    readonly sourceLabel: string;
    readonly sourceFingerprint: string;
    readonly files: readonly CareerOpsPreviewFile[];
    readonly profileFacts: readonly {
        readonly sourceIdentity: string;
        readonly sourceRelativePath: string;
        readonly predicate: string;
        readonly value: string | number | boolean | null;
        readonly confirmationRequired: true;
    }[];
    readonly applications: readonly CareerOpsPreviewApplication[];
    readonly passiveMappings: readonly CareerOpsPassiveMappingInput[];
    readonly warnings: readonly string[];
    readonly unsupported: readonly string[];
}
export interface CareerOpsDiscovery {
    readonly preview: CareerOpsImportPreview;
    /** Server-owned plan. Never accept this structure back from a browser. */
    readonly plan: ApplyCareerOpsImportInput;
}
export declare function normalizeKey(value: string): string;
export declare function mapCareerOpsStatus(raw: string): CareerOpsApplicationInput["state"] | null;
export declare function discoverCareerOps(rootPath: string): Promise<CareerOpsDiscovery>;
//# sourceMappingURL=index.d.ts.map