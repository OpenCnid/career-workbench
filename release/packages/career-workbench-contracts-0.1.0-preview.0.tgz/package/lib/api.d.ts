import { type Static } from "@sinclair/typebox";
export declare const SourceLocatorSchema: import("@sinclair/typebox").TObject<{
    sourceId: import("@sinclair/typebox").TString;
    start: import("@sinclair/typebox").TInteger;
    end: import("@sinclair/typebox").TInteger;
    quote: import("@sinclair/typebox").TString;
}>;
export declare const CreateWorkspaceBodySchema: import("@sinclair/typebox").TObject<{
    displayName: import("@sinclair/typebox").TString;
    candidateName: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    targetRole: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    targetPriorities: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    locationPreference: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    deferTargetPreferences: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    rubricPreset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TLiteral<"balanced_fit">>;
    locale: import("@sinclair/typebox").TString;
    timezone: import("@sinclair/typebox").TString;
}>;
export declare const CaptureSourceBodySchema: import("@sinclair/typebox").TObject<{
    kind: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    trustClass: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    mediaType: import("@sinclair/typebox").TString;
    text: import("@sinclair/typebox").TString;
    originalLocator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>;
export declare const ProposeProfileFactBodySchema: import("@sinclair/typebox").TObject<{
    factType: import("@sinclair/typebox").TString;
    subject: import("@sinclair/typebox").TString;
    predicate: import("@sinclair/typebox").TString;
    value: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TNull]>;
    sourceLocators: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        sourceId: import("@sinclair/typebox").TString;
        start: import("@sinclair/typebox").TInteger;
        end: import("@sinclair/typebox").TInteger;
        quote: import("@sinclair/typebox").TString;
    }>>;
    proposedBy: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
}>;
export declare const AddCareerHistoryEntryBodySchema: import("@sinclair/typebox").TObject<{
    personName: import("@sinclair/typebox").TString;
    roleTitle: import("@sinclair/typebox").TString;
    organization: import("@sinclair/typebox").TString;
    dateRange: import("@sinclair/typebox").TString;
    achievements: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>;
export declare const ConfirmProfileFactBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    outcome: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"confirm">;
    }>, import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"correct">;
        value: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TNull]>;
        locator: import("@sinclair/typebox").TObject<{
            sourceId: import("@sinclair/typebox").TString;
            start: import("@sinclair/typebox").TInteger;
            end: import("@sinclair/typebox").TInteger;
            quote: import("@sinclair/typebox").TString;
        }>;
    }>, import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"narrative_only">;
    }>, import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"cannot_confirm">;
    }>]>;
}>;
export declare const CaptureOpportunityBodySchema: import("@sinclair/typebox").TObject<{
    sourceDocumentId: import("@sinclair/typebox").TString;
    organization: import("@sinclair/typebox").TString;
    roleTitle: import("@sinclair/typebox").TString;
    originalUrl: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    location: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    workArrangement: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    advertisedCompensation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    requisitionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>;
export declare const UpsertSearchProfileBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
    targetRoles: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    seniority: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>>;
    locations: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    workArrangements: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>>;
    minimumCompensation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
    compensationCurrency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    aiFocus: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    priorities: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    exclusions: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    active: import("@sinclair/typebox").TBoolean;
}>;
export declare const RecordDiscoveryLeadBodySchema: import("@sinclair/typebox").TObject<{
    organization: import("@sinclair/typebox").TString;
    roleTitle: import("@sinclair/typebox").TString;
    originalUrl: import("@sinclair/typebox").TString;
    postingText: import("@sinclair/typebox").TString;
    location: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    workArrangement: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    advertisedCompensation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    requisitionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    whyFound: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    matchedCriteria: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    gaps: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    risks: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>;
export declare const TriageDiscoveryLeadBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    decision: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"new">, import("@sinclair/typebox").TLiteral<"shortlisted">, import("@sinclair/typebox").TLiteral<"dismissed">]>;
    note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>;
export declare const ProposeEvidenceBodySchema: import("@sinclair/typebox").TObject<{
    classification: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    claim: import("@sinclair/typebox").TString;
    sourceId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    locator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        sourceId: import("@sinclair/typebox").TString;
        start: import("@sinclair/typebox").TInteger;
        end: import("@sinclair/typebox").TInteger;
        quote: import("@sinclair/typebox").TString;
    }>>;
    candidateFactId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    proposedByOperationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>;
export declare const DecideEvidenceBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    decision: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"accepted">, import("@sinclair/typebox").TLiteral<"rejected">]>;
    reason: import("@sinclair/typebox").TString;
}>;
export declare const CreateRubricBodySchema: import("@sinclair/typebox").TObject<{
    semanticVersion: import("@sinclair/typebox").TString;
    name: import("@sinclair/typebox").TString;
    dimensions: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        key: import("@sinclair/typebox").TString;
        label: import("@sinclair/typebox").TString;
        weightBasisPoints: import("@sinclair/typebox").TInteger;
        missingInput: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
        criticalMinimumBasisPoints: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TInteger, import("@sinclair/typebox").TNull]>;
    }>>;
    thresholds: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TInteger>;
    displayScale: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<5>, import("@sinclair/typebox").TLiteral<100>]>;
}>;
export declare const EvaluateBodySchema: import("@sinclair/typebox").TObject<{
    opportunityId: import("@sinclair/typebox").TString;
    rubricId: import("@sinclair/typebox").TString;
    operationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    dimensionInputs: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        dimensionKey: import("@sinclair/typebox").TString;
        semanticScoreBasisPoints: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TInteger, import("@sinclair/typebox").TNull]>;
        evidenceIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
        disposition: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
    }>>;
    contradictions: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>>;
}>;
export declare const StartOperationBodySchema: import("@sinclair/typebox").TObject<{
    kind: import("@sinclair/typebox").TString;
    inputIdentity: import("@sinclair/typebox").TString;
    requestedCapabilities: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    route: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    dshSessionId: import("@sinclair/typebox").TString;
    parentOperationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    provider: import("@sinclair/typebox").TString;
    model: import("@sinclair/typebox").TString;
    reasoningEffort: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    admissionOnly: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
}>;
export declare const OperationActivityBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    phase: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    message: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    messageId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    requestId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>;
export declare const TerminalOperationBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    state: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    category: import("@sinclair/typebox").TString;
    message: import("@sinclair/typebox").TString;
    resultIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    artifactIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>;
export declare const CancelOperationBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    reason: import("@sinclair/typebox").TString;
}>;
export declare const RequestChildFollowupBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    message: import("@sinclair/typebox").TString;
}>;
export declare const CorrectFactBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    value: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TNull]>;
    sourceText: import("@sinclair/typebox").TString;
}>;
export declare const ComparisonProjectionBodySchema: import("@sinclair/typebox").TObject<{
    evaluationIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>;
export declare const ProposeComparisonBodySchema: import("@sinclair/typebox").TObject<{
    evaluationIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    policyVersion: import("@sinclair/typebox").TString;
    scenarios: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        label: import("@sinclair/typebox").TString;
        weightsBasisPoints: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TInteger>;
    }>>;
    tradeoffs: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>;
export declare const AcceptComparisonBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    approvalId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    expectedApprovalRevision: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
}>;
export declare const RequestApprovalBodySchema: import("@sinclair/typebox").TObject<{
    effectKind: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"comparison.accept">, import("@sinclair/typebox").TLiteral<"artifact.review">, import("@sinclair/typebox").TLiteral<"application.transition">]>;
    targetId: import("@sinclair/typebox").TString;
    expectedRevision: import("@sinclair/typebox").TInteger;
    expiresInSeconds: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
    applicationTransition: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        state: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
        effectiveDate: import("@sinclair/typebox").TString;
        note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    }>>;
}>;
export declare const DecideApprovalBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    decision: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"approved">, import("@sinclair/typebox").TLiteral<"denied">]>;
}>;
export declare const ExportWorkspaceBodySchema: import("@sinclair/typebox").TObject<{
    selectedArtifactIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>;
export declare const PreviewCareerOpsImportBodySchema: import("@sinclair/typebox").TObject<{
    sourceDirectory: import("@sinclair/typebox").TString;
}>;
export declare const ApplyCareerOpsImportBodySchema: import("@sinclair/typebox").TObject<{
    sourceFingerprint: import("@sinclair/typebox").TString;
    confirm: import("@sinclair/typebox").TLiteral<true>;
    selectedMappingIds: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>>;
}>;
export declare const CreateApplicationBodySchema: import("@sinclair/typebox").TObject<{
    opportunityId: import("@sinclair/typebox").TString;
    effectiveDate: import("@sinclair/typebox").TString;
    note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>;
export declare const TransitionApplicationBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    state: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    effectiveDate: import("@sinclair/typebox").TString;
    note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    approvalId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    expectedApprovalRevision: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
}>;
export declare const UpdateOpportunitySignalsBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    sourceStatus: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    legitimacyStatus: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
}>;
export declare const CreateCandidateArtifactBodySchema: import("@sinclair/typebox").TObject<{
    kind: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    opportunityId: import("@sinclair/typebox").TString;
    factIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    styleNote: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>;
export declare const ReviewArtifactBodySchema: import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    approvalId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    expectedApprovalRevision: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
}>;
export declare const IdParameterSchema: import("@sinclair/typebox").TObject<{
    id: import("@sinclair/typebox").TString;
}>;
export type CreateWorkspaceBody = Static<typeof CreateWorkspaceBodySchema>;
export type CaptureSourceBody = Static<typeof CaptureSourceBodySchema>;
export type ProposeProfileFactBody = Static<typeof ProposeProfileFactBodySchema>;
export type AddCareerHistoryEntryBody = Static<typeof AddCareerHistoryEntryBodySchema>;
export type ConfirmProfileFactBody = Static<typeof ConfirmProfileFactBodySchema>;
export type CaptureOpportunityBody = Static<typeof CaptureOpportunityBodySchema>;
export type UpsertSearchProfileBody = Static<typeof UpsertSearchProfileBodySchema>;
export type RecordDiscoveryLeadBody = Static<typeof RecordDiscoveryLeadBodySchema>;
export type TriageDiscoveryLeadBody = Static<typeof TriageDiscoveryLeadBodySchema>;
export type ProposeEvidenceBody = Static<typeof ProposeEvidenceBodySchema>;
export type DecideEvidenceBody = Static<typeof DecideEvidenceBodySchema>;
export type CreateRubricBody = Static<typeof CreateRubricBodySchema>;
export type EvaluateBody = Static<typeof EvaluateBodySchema>;
export type StartOperationBody = Static<typeof StartOperationBodySchema>;
export type OperationActivityBody = Static<typeof OperationActivityBodySchema>;
export type TerminalOperationBody = Static<typeof TerminalOperationBodySchema>;
export type CancelOperationBody = Static<typeof CancelOperationBodySchema>;
export type RequestChildFollowupBody = Static<typeof RequestChildFollowupBodySchema>;
export type CorrectFactBody = Static<typeof CorrectFactBodySchema>;
export type ComparisonProjectionBody = Static<typeof ComparisonProjectionBodySchema>;
export type ProposeComparisonBody = Static<typeof ProposeComparisonBodySchema>;
export type AcceptComparisonBody = Static<typeof AcceptComparisonBodySchema>;
export type RequestApprovalBody = Static<typeof RequestApprovalBodySchema>;
export type DecideApprovalBody = Static<typeof DecideApprovalBodySchema>;
export type ExportWorkspaceBody = Static<typeof ExportWorkspaceBodySchema>;
export type PreviewCareerOpsImportBody = Static<typeof PreviewCareerOpsImportBodySchema>;
export type ApplyCareerOpsImportBody = Static<typeof ApplyCareerOpsImportBodySchema>;
export type CreateApplicationBody = Static<typeof CreateApplicationBodySchema>;
export type TransitionApplicationBody = Static<typeof TransitionApplicationBodySchema>;
export type UpdateOpportunitySignalsBody = Static<typeof UpdateOpportunitySignalsBodySchema>;
export type CreateCandidateArtifactBody = Static<typeof CreateCandidateArtifactBodySchema>;
export type ReviewArtifactBody = Static<typeof ReviewArtifactBodySchema>;
export interface ApprovalView {
    readonly id: string;
    readonly revision: number;
    readonly commandId: string;
    readonly effectKind: "comparison.accept" | "artifact.review" | "application.transition";
    readonly targetId: string;
    readonly effectDigest: string;
    readonly summary: string;
    readonly effectDescription: string;
    readonly expectedRevisions: Readonly<Record<string, number>>;
    readonly state: "pending" | "approved" | "denied" | "expired" | "consumed";
    readonly expiresAt: string;
    readonly approvingInteractionId: string | null;
}
export interface ApprovalListResponse {
    readonly contractVersion: "v1";
    readonly approvals: readonly ApprovalView[];
}
export interface WorkspaceView {
    readonly id: string;
    readonly displayName: string;
    readonly revision: number;
    readonly defaultRubricId: string | null;
    readonly locale: string;
    readonly timezone: string;
}
export interface SourceView {
    readonly id: string;
    readonly revision: number;
    readonly createdAt: string;
    readonly kind: string;
    readonly trustClass: string;
    readonly contentDigest: string;
    readonly byteLength: number;
    readonly inlineText: string | null;
}
export interface ProfileFactView {
    readonly id: string;
    readonly revision: number;
    readonly factType: string;
    readonly subject: string;
    readonly predicate: string;
    readonly value: string | number | boolean | null;
    readonly status: string;
    readonly sourceLocators: readonly Static<typeof SourceLocatorSchema>[];
    readonly supersedesFactId: string | null;
}
export interface OpportunityView {
    readonly id: string;
    readonly revision: number;
    readonly sourceDocumentId: string;
    readonly organization: string;
    readonly roleTitle: string;
    readonly originalUrl: string | null;
    readonly location: string | null;
    readonly workArrangement: string | null;
    readonly advertisedCompensation: string | null;
    readonly requisitionId: string | null;
    readonly sourceStatus: string;
    readonly legitimacyStatus: string;
    readonly workflowState: string;
}
export interface SearchProfileView {
    readonly id: string;
    readonly revision: number;
    readonly targetRoles: readonly string[];
    readonly seniority: readonly string[];
    readonly locations: readonly string[];
    readonly workArrangements: readonly string[];
    readonly minimumCompensation: number | null;
    readonly compensationCurrency: string | null;
    readonly aiFocus: string | null;
    readonly priorities: readonly string[];
    readonly exclusions: readonly string[];
    readonly active: boolean;
}
export interface DiscoveryLeadView {
    readonly id: string;
    readonly revision: number;
    readonly createdAt: string;
    readonly sourceDocumentId: string;
    readonly sourceContentDigest: string;
    readonly searchProfileId: string;
    readonly searchProfileRevision: number;
    readonly searchCriteriaDigest: string;
    readonly operationId: string;
    readonly organization: string;
    readonly roleTitle: string;
    readonly originalUrl: string;
    readonly normalizedUrl: string;
    readonly location: string | null;
    readonly workArrangement: string | null;
    readonly advertisedCompensation: string | null;
    readonly requisitionId: string | null;
    readonly whyFound: readonly string[];
    readonly matchedCriteria: readonly string[];
    readonly gaps: readonly string[];
    readonly risks: readonly string[];
    readonly state: "new" | "shortlisted" | "dismissed";
    readonly triageNote: string | null;
    readonly resultOpportunityId: string | null;
}
export interface EvidenceView {
    readonly id: string;
    readonly revision: number;
    readonly classification: string;
    readonly claim: string;
    readonly sourceId: string | null;
    readonly candidateFactId: string | null;
    readonly decision: string;
    readonly decisionReason: string | null;
}
export interface DimensionScoreView {
    readonly dimensionKey: string;
    readonly inputBasisPoints: number;
    readonly weightedNumerator: number;
    readonly weightBasisPoints: number;
    readonly missing: boolean;
}
export interface EvaluationView {
    readonly id: string;
    readonly revision: number;
    readonly opportunityId: string;
    readonly rubricId: string;
    readonly acceptedEvidenceIds: readonly string[];
    readonly dimensionScores: readonly DimensionScoreView[];
    readonly aggregateScoreBasisPoints: number;
    readonly displayScore: string;
    readonly arithmeticExplanation: string;
    readonly state: string;
    readonly gaps: readonly string[];
    readonly contradictions: readonly string[];
    readonly operationId: string | null;
    readonly staleReason: string | null;
}
export interface ArtifactView {
    readonly id: string;
    readonly revision: number;
    readonly kind: string;
    readonly mediaType: string;
    readonly contentDigest: string;
    readonly byteLength: number;
    readonly evaluationIds: readonly string[];
    readonly sourceIds: readonly string[];
    readonly factIds: readonly string[];
    readonly evidenceIds: readonly string[];
    readonly state: string;
    readonly staleReason: string | null;
}
export interface OperationView {
    readonly id: string;
    readonly revision: number;
    readonly kind: string;
    readonly state: string;
    readonly route: string;
    readonly inputIdentity: string | null;
    readonly inputRevision: number | null;
    readonly inputDigest: string | null;
    readonly resourceLimits: Readonly<Record<string, number>>;
    readonly requestedCapabilities: readonly string[];
    readonly dshSessionId: string | null;
    readonly parentOperationId: string | null;
    readonly startedAt: string | null;
    readonly lastActivityAt: string;
    readonly terminalAt: string | null;
    readonly terminalCategory: string | null;
    readonly terminalMessage: string | null;
    readonly resultIds: readonly string[];
    readonly artifactIds: readonly string[];
    readonly cancellationRequestedAt: string | null;
}
export interface ComparisonView {
    readonly id: string;
    readonly revision: number;
    readonly policyVersion: string;
    readonly evaluationInputs: readonly Readonly<Record<string, unknown>>[];
    readonly scenarios: readonly Readonly<Record<string, unknown>>[];
    readonly tradeoffs: readonly string[];
    readonly state: string;
    readonly operationId: string;
    readonly acceptedAt: string | null;
    readonly staleReason: string | null;
}
export interface ApplicationView {
    readonly id: string;
    readonly revision: number;
    readonly opportunityId: string;
    readonly state: string;
    readonly stateRevision: number;
    readonly effectiveDate: string;
    readonly sourceIds: readonly string[];
    readonly note: string | null;
}
export interface ImportManifestView {
    readonly id: string;
    readonly revision: number;
    readonly provider: string;
    readonly upstreamRevision: string;
    readonly observedVersion: string | null;
    readonly sourceFingerprint: string;
    readonly sourceLabel: string;
    readonly sources: readonly Readonly<Record<string, unknown>>[];
    readonly mappings: readonly Readonly<Record<string, unknown>>[];
    readonly warnings: readonly string[];
    readonly unsupported: readonly string[];
}
export interface DomainEventView {
    readonly sequence: number;
    readonly eventKind: string;
    readonly aggregateId: string;
    readonly aggregateRevision: number;
    readonly timestamp: string;
    readonly actor: string;
    readonly payload: Readonly<Record<string, unknown>>;
}
export interface SnapshotResponse {
    readonly contractVersion: "v1";
    readonly workspace: WorkspaceView | null;
    readonly sources: readonly SourceView[];
    readonly profileFacts: readonly ProfileFactView[];
    readonly searchProfiles: readonly SearchProfileView[];
    readonly discoveryLeads: readonly DiscoveryLeadView[];
    readonly opportunities: readonly OpportunityView[];
    readonly evidence: readonly EvidenceView[];
    readonly rubrics: readonly Readonly<Record<string, unknown>>[];
    readonly evaluations: readonly EvaluationView[];
    readonly comparisons: readonly ComparisonView[];
    readonly applications: readonly ApplicationView[];
    readonly importManifests: readonly ImportManifestView[];
    readonly artifacts: readonly ArtifactView[];
    readonly operations: readonly OperationView[];
    readonly events: readonly DomainEventView[];
}
export declare const DiagnosticsResponseSchema: import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    version: import("@sinclair/typebox").TString;
    workspaceConfigured: import("@sinclair/typebox").TBoolean;
    schemaVersion: import("@sinclair/typebox").TInteger;
    storage: import("@sinclair/typebox").TString;
    journalMode: import("@sinclair/typebox").TString;
    capabilities: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TBoolean>;
    security: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TBoolean>;
    runtimeVersions: import("@sinclair/typebox").TObject<{
        node: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        pnpm: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        typescript: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        careerWorkbench: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
    }>;
    compatibility: import("@sinclair/typebox").TObject<{
        state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        mismatches: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
        deepSeekHarness: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            resolved: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        nativeRlm: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            resolved: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        careerOps: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            resolved: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        cordis: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        patches: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
            identity: import("@sinclair/typebox").TString;
            sha256: import("@sinclair/typebox").TString;
            resolvedSha256: import("@sinclair/typebox").TString;
            application: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"runtime_package">, import("@sinclair/typebox").TLiteral<"bundle_host">]>;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>>;
    }>;
    recentErrorCategories: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>>;
}>;
export type DiagnosticsResponse = Static<typeof DiagnosticsResponseSchema>;
export declare const API_SCHEMAS: readonly [import("@sinclair/typebox").TObject<{
    displayName: import("@sinclair/typebox").TString;
    candidateName: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    targetRole: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    targetPriorities: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    locationPreference: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    deferTargetPreferences: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
    rubricPreset: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TLiteral<"balanced_fit">>;
    locale: import("@sinclair/typebox").TString;
    timezone: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    kind: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    trustClass: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    mediaType: import("@sinclair/typebox").TString;
    text: import("@sinclair/typebox").TString;
    originalLocator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    factType: import("@sinclair/typebox").TString;
    subject: import("@sinclair/typebox").TString;
    predicate: import("@sinclair/typebox").TString;
    value: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TNull]>;
    sourceLocators: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        sourceId: import("@sinclair/typebox").TString;
        start: import("@sinclair/typebox").TInteger;
        end: import("@sinclair/typebox").TInteger;
        quote: import("@sinclair/typebox").TString;
    }>>;
    proposedBy: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
}>, import("@sinclair/typebox").TObject<{
    personName: import("@sinclair/typebox").TString;
    roleTitle: import("@sinclair/typebox").TString;
    organization: import("@sinclair/typebox").TString;
    dateRange: import("@sinclair/typebox").TString;
    achievements: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    outcome: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"confirm">;
    }>, import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"correct">;
        value: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TNull]>;
        locator: import("@sinclair/typebox").TObject<{
            sourceId: import("@sinclair/typebox").TString;
            start: import("@sinclair/typebox").TInteger;
            end: import("@sinclair/typebox").TInteger;
            quote: import("@sinclair/typebox").TString;
        }>;
    }>, import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"narrative_only">;
    }>, import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"cannot_confirm">;
    }>]>;
}>, import("@sinclair/typebox").TObject<{
    sourceDocumentId: import("@sinclair/typebox").TString;
    organization: import("@sinclair/typebox").TString;
    roleTitle: import("@sinclair/typebox").TString;
    originalUrl: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    location: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    workArrangement: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    advertisedCompensation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    requisitionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
    targetRoles: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    seniority: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>>;
    locations: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    workArrangements: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>>;
    minimumCompensation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
    compensationCurrency: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    aiFocus: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    priorities: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    exclusions: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    active: import("@sinclair/typebox").TBoolean;
}>, import("@sinclair/typebox").TObject<{
    organization: import("@sinclair/typebox").TString;
    roleTitle: import("@sinclair/typebox").TString;
    originalUrl: import("@sinclair/typebox").TString;
    postingText: import("@sinclair/typebox").TString;
    location: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    workArrangement: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    advertisedCompensation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    requisitionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    whyFound: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    matchedCriteria: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    gaps: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    risks: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    decision: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"new">, import("@sinclair/typebox").TLiteral<"shortlisted">, import("@sinclair/typebox").TLiteral<"dismissed">]>;
    note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    classification: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    claim: import("@sinclair/typebox").TString;
    sourceId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    locator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        sourceId: import("@sinclair/typebox").TString;
        start: import("@sinclair/typebox").TInteger;
        end: import("@sinclair/typebox").TInteger;
        quote: import("@sinclair/typebox").TString;
    }>>;
    candidateFactId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    proposedByOperationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    decision: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"accepted">, import("@sinclair/typebox").TLiteral<"rejected">]>;
    reason: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    semanticVersion: import("@sinclair/typebox").TString;
    name: import("@sinclair/typebox").TString;
    dimensions: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        key: import("@sinclair/typebox").TString;
        label: import("@sinclair/typebox").TString;
        weightBasisPoints: import("@sinclair/typebox").TInteger;
        missingInput: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
        criticalMinimumBasisPoints: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TInteger, import("@sinclair/typebox").TNull]>;
    }>>;
    thresholds: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TInteger>;
    displayScale: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<5>, import("@sinclair/typebox").TLiteral<100>]>;
}>, import("@sinclair/typebox").TObject<{
    opportunityId: import("@sinclair/typebox").TString;
    rubricId: import("@sinclair/typebox").TString;
    operationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    dimensionInputs: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        dimensionKey: import("@sinclair/typebox").TString;
        semanticScoreBasisPoints: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TInteger, import("@sinclair/typebox").TNull]>;
        evidenceIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
        disposition: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
    }>>;
    contradictions: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>>;
}>, import("@sinclair/typebox").TObject<{
    evaluationIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    evaluationIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    policyVersion: import("@sinclair/typebox").TString;
    scenarios: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        label: import("@sinclair/typebox").TString;
        weightsBasisPoints: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TInteger>;
    }>>;
    tradeoffs: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    approvalId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    expectedApprovalRevision: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
}>, import("@sinclair/typebox").TObject<{
    effectKind: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"comparison.accept">, import("@sinclair/typebox").TLiteral<"artifact.review">, import("@sinclair/typebox").TLiteral<"application.transition">]>;
    targetId: import("@sinclair/typebox").TString;
    expectedRevision: import("@sinclair/typebox").TInteger;
    expiresInSeconds: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
    applicationTransition: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        state: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
        effectiveDate: import("@sinclair/typebox").TString;
        note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    }>>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    decision: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"approved">, import("@sinclair/typebox").TLiteral<"denied">]>;
}>, import("@sinclair/typebox").TObject<{
    selectedArtifactIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    sourceDirectory: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    sourceFingerprint: import("@sinclair/typebox").TString;
    confirm: import("@sinclair/typebox").TLiteral<true>;
    selectedMappingIds: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>>;
}>, import("@sinclair/typebox").TObject<{
    opportunityId: import("@sinclair/typebox").TString;
    effectiveDate: import("@sinclair/typebox").TString;
    note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    state: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    effectiveDate: import("@sinclair/typebox").TString;
    note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    approvalId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    expectedApprovalRevision: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    sourceStatus: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    legitimacyStatus: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
}>, import("@sinclair/typebox").TObject<{
    kind: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    opportunityId: import("@sinclair/typebox").TString;
    factIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    styleNote: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    approvalId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    expectedApprovalRevision: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TInteger>;
}>, import("@sinclair/typebox").TObject<{
    kind: import("@sinclair/typebox").TString;
    inputIdentity: import("@sinclair/typebox").TString;
    requestedCapabilities: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    route: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    dshSessionId: import("@sinclair/typebox").TString;
    parentOperationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    provider: import("@sinclair/typebox").TString;
    model: import("@sinclair/typebox").TString;
    reasoningEffort: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    admissionOnly: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    phase: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    message: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    messageId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    requestId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    state: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    category: import("@sinclair/typebox").TString;
    message: import("@sinclair/typebox").TString;
    resultIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    artifactIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    reason: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    message: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    value: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TNull]>;
    sourceText: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    version: import("@sinclair/typebox").TString;
    workspaceConfigured: import("@sinclair/typebox").TBoolean;
    schemaVersion: import("@sinclair/typebox").TInteger;
    storage: import("@sinclair/typebox").TString;
    journalMode: import("@sinclair/typebox").TString;
    capabilities: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TBoolean>;
    security: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TBoolean>;
    runtimeVersions: import("@sinclair/typebox").TObject<{
        node: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        pnpm: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        typescript: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        careerWorkbench: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
    }>;
    compatibility: import("@sinclair/typebox").TObject<{
        state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        mismatches: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
        deepSeekHarness: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            resolved: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        nativeRlm: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            resolved: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        careerOps: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            resolved: import("@sinclair/typebox").TObject<{
                revision: import("@sinclair/typebox").TString;
                tag: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
                version: import("@sinclair/typebox").TString;
            }>;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        cordis: import("@sinclair/typebox").TObject<{
            expected: import("@sinclair/typebox").TString;
            resolved: import("@sinclair/typebox").TString;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>;
        patches: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
            identity: import("@sinclair/typebox").TString;
            sha256: import("@sinclair/typebox").TString;
            resolvedSha256: import("@sinclair/typebox").TString;
            application: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"runtime_package">, import("@sinclair/typebox").TLiteral<"bundle_host">]>;
            state: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"ready">, import("@sinclair/typebox").TLiteral<"mismatch">]>;
        }>>;
    }>;
    recentErrorCategories: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>>;
}>];
//# sourceMappingURL=api.d.ts.map