export * from "./api.js";
export * from "./schemas.js";
export * from "./validation.js";
export declare const ALL_PUBLIC_SCHEMAS: readonly [import("@sinclair/typebox").TUnsafe<string>, import("@sinclair/typebox").TUnsafe<string>, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>, import("@sinclair/typebox").TObject<{
    error: import("@sinclair/typebox").TObject<{
        code: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
        message: import("@sinclair/typebox").TString;
        retryable: import("@sinclair/typebox").TBoolean;
        details: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>>;
    }>;
}>, import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    workspaceId: import("@sinclair/typebox").TUnsafe<string>;
    commandId: import("@sinclair/typebox").TUnsafe<string>;
    commandKind: import("@sinclair/typebox").TString;
    actor: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    idempotencyKey: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    expectedRevisions: import("@sinclair/typebox").TNever;
    operationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnsafe<string>>;
    payload: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>;
}>, import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    workspaceId: import("@sinclair/typebox").TUnsafe<string>;
    queryKind: import("@sinclair/typebox").TString;
    cursor: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    limit: import("@sinclair/typebox").TInteger;
    filters: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>;
}>, import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    sequence: import("@sinclair/typebox").TInteger;
    eventKind: import("@sinclair/typebox").TString;
    schemaVersion: import("@sinclair/typebox").TInteger;
    workspaceId: import("@sinclair/typebox").TUnsafe<string>;
    aggregateId: import("@sinclair/typebox").TUnsafe<string>;
    aggregateRevision: import("@sinclair/typebox").TInteger;
    commandId: import("@sinclair/typebox").TUnsafe<string>;
    operationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnsafe<string>>;
    actor: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    timestamp: import("@sinclair/typebox").TString;
    payload: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>;
}>, import("@sinclair/typebox").TObject<{
    displayName: import("@sinclair/typebox").TString;
    locale: import("@sinclair/typebox").TString;
    timezone: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    kind: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    trustClass: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    mediaType: import("@sinclair/typebox").TString;
    text: import("@sinclair/typebox").TString;
    originalLocator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    factType: import("@sinclair/typebox").TString;
    subject: import("@sinclair/typebox").TString;
    predicate: import("@sinclair/typebox").TString;
    value: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TNull]>;
    sourceLocators: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        sourceId: import("@sinclair/typebox").TString;
        start: import("@sinclair/typebox").TInteger;
        end: import("@sinclair/typebox").TInteger;
        quote: import("@sinclair/typebox").TString;
    }>>;
    proposedBy: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    outcome: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"confirm">;
    }>, import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"correct">;
        value: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TNull]>;
        locator: import("@sinclair/typebox").TObject<{
            sourceId: import("@sinclair/typebox").TString;
            start: import("@sinclair/typebox").TInteger;
            end: import("@sinclair/typebox").TInteger;
            quote: import("@sinclair/typebox").TString;
        }>;
    }>, import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"narrative_only">;
    }>, import("@sinclair/typebox").TObject<{
        kind: import("@sinclair/typebox").TLiteral<"cannot_confirm">;
    }>]>;
}>, import("@sinclair/typebox").TObject<{
    sourceDocumentId: import("@sinclair/typebox").TString;
    organization: import("@sinclair/typebox").TString;
    roleTitle: import("@sinclair/typebox").TString;
    originalUrl: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    location: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    workArrangement: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    advertisedCompensation: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    requisitionId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    classification: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    claim: import("@sinclair/typebox").TString;
    sourceId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    locator: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TObject<{
        sourceId: import("@sinclair/typebox").TString;
        start: import("@sinclair/typebox").TInteger;
        end: import("@sinclair/typebox").TInteger;
        quote: import("@sinclair/typebox").TString;
    }>>;
    candidateFactId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    proposedByOperationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    decision: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<"accepted">, import("@sinclair/typebox").TLiteral<"rejected">]>;
    reason: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    semanticVersion: import("@sinclair/typebox").TString;
    name: import("@sinclair/typebox").TString;
    dimensions: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        key: import("@sinclair/typebox").TString;
        label: import("@sinclair/typebox").TString;
        weightBasisPoints: import("@sinclair/typebox").TInteger;
        missingInput: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
        criticalMinimumBasisPoints: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TInteger, import("@sinclair/typebox").TNull]>;
    }>>;
    thresholds: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TInteger>;
    displayScale: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TLiteral<5>, import("@sinclair/typebox").TLiteral<100>]>;
}>, import("@sinclair/typebox").TObject<{
    opportunityId: import("@sinclair/typebox").TString;
    rubricId: import("@sinclair/typebox").TString;
    operationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    dimensionInputs: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        dimensionKey: import("@sinclair/typebox").TString;
        semanticScoreBasisPoints: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TInteger, import("@sinclair/typebox").TNull]>;
        evidenceIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
        disposition: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNull]>;
    }>>;
    contradictions: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>>;
}>, import("@sinclair/typebox").TObject<{
    evaluationIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    evaluationIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    policyVersion: import("@sinclair/typebox").TString;
    scenarios: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TObject<{
        label: import("@sinclair/typebox").TString;
        weightsBasisPoints: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TInteger>;
    }>>;
    tradeoffs: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
}>, import("@sinclair/typebox").TObject<{
    sourceDirectory: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    sourceFingerprint: import("@sinclair/typebox").TString;
    confirm: import("@sinclair/typebox").TLiteral<true>;
}>, import("@sinclair/typebox").TObject<{
    opportunityId: import("@sinclair/typebox").TString;
    effectiveDate: import("@sinclair/typebox").TString;
    note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    state: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    effectiveDate: import("@sinclair/typebox").TString;
    note: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    sourceStatus: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    legitimacyStatus: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
}>, import("@sinclair/typebox").TObject<{
    kind: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    opportunityId: import("@sinclair/typebox").TString;
    factIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    styleNote: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
}>, import("@sinclair/typebox").TObject<{
    kind: import("@sinclair/typebox").TString;
    inputIdentity: import("@sinclair/typebox").TString;
    requestedCapabilities: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    route: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    dshSessionId: import("@sinclair/typebox").TString;
    parentOperationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    provider: import("@sinclair/typebox").TString;
    model: import("@sinclair/typebox").TString;
    reasoningEffort: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    admissionOnly: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TBoolean>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    phase: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    message: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    messageId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    requestId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    state: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    category: import("@sinclair/typebox").TString;
    message: import("@sinclair/typebox").TString;
    resultIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
    artifactIds: import("@sinclair/typebox").TArray<import("@sinclair/typebox").TString>;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    reason: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    message: import("@sinclair/typebox").TString;
}>, import("@sinclair/typebox").TObject<{
    expectedRevision: import("@sinclair/typebox").TInteger;
    value: import("@sinclair/typebox").TUnion<[import("@sinclair/typebox").TString, import("@sinclair/typebox").TNumber, import("@sinclair/typebox").TBoolean, import("@sinclair/typebox").TNull]>;
    sourceText: import("@sinclair/typebox").TString;
}>];
//# sourceMappingURL=index.d.ts.map