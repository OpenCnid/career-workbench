import { type Static } from "@sinclair/typebox";
export declare const WorkspaceIdSchema: import("@sinclair/typebox").TUnsafe<string>;
export declare const EntityIdSchema: import("@sinclair/typebox").TUnsafe<string>;
export declare const RevisionSchema: import("@sinclair/typebox").TInteger;
export declare const SequenceSchema: import("@sinclair/typebox").TInteger;
export declare const UtcTimestampSchema: import("@sinclair/typebox").TString;
export declare const ErrorCodeSchema: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
export declare const PublicErrorSchema: import("@sinclair/typebox").TObject<{
    error: import("@sinclair/typebox").TObject<{
        code: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
        message: import("@sinclair/typebox").TString;
        retryable: import("@sinclair/typebox").TBoolean;
        details: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>>;
    }>;
}>;
export declare const ActorClassSchema: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
export declare const CommandEnvelopeSchema: import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    workspaceId: import("@sinclair/typebox").TUnsafe<string>;
    commandId: import("@sinclair/typebox").TUnsafe<string>;
    commandKind: import("@sinclair/typebox").TString;
    actor: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    idempotencyKey: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    expectedRevisions: import("@sinclair/typebox").TNever;
    operationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnsafe<string>>;
    payload: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>;
}>;
export declare const QueryEnvelopeSchema: import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    workspaceId: import("@sinclair/typebox").TUnsafe<string>;
    queryKind: import("@sinclair/typebox").TString;
    cursor: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    limit: import("@sinclair/typebox").TInteger;
    filters: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>;
}>;
export declare const DomainEventSchema: import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    sequence: import("@sinclair/typebox").TInteger;
    eventKind: import("@sinclair/typebox").TString;
    schemaVersion: import("@sinclair/typebox").TInteger;
    workspaceId: import("@sinclair/typebox").TUnsafe<string>;
    aggregateId: import("@sinclair/typebox").TUnsafe<string>;
    aggregateRevision: import("@sinclair/typebox").TInteger;
    commandId: import("@sinclair/typebox").TUnsafe<string>;
    operationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnsafe<string>>;
    actor: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    timestamp: import("@sinclair/typebox").TString;
    payload: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>;
}>;
export type PublicError = Static<typeof PublicErrorSchema>;
export type CommandEnvelope = Static<typeof CommandEnvelopeSchema>;
export type QueryEnvelope = Static<typeof QueryEnvelopeSchema>;
export type DomainEvent = Static<typeof DomainEventSchema>;
export declare const PUBLIC_SCHEMAS: readonly [import("@sinclair/typebox").TUnsafe<string>, import("@sinclair/typebox").TUnsafe<string>, import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>, import("@sinclair/typebox").TObject<{
    error: import("@sinclair/typebox").TObject<{
        code: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
        message: import("@sinclair/typebox").TString;
        retryable: import("@sinclair/typebox").TBoolean;
        details: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>>;
    }>;
}>, import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    workspaceId: import("@sinclair/typebox").TUnsafe<string>;
    commandId: import("@sinclair/typebox").TUnsafe<string>;
    commandKind: import("@sinclair/typebox").TString;
    actor: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    idempotencyKey: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    expectedRevisions: import("@sinclair/typebox").TNever;
    operationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnsafe<string>>;
    payload: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>;
}>, import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    workspaceId: import("@sinclair/typebox").TUnsafe<string>;
    queryKind: import("@sinclair/typebox").TString;
    cursor: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TString>;
    limit: import("@sinclair/typebox").TInteger;
    filters: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>;
}>, import("@sinclair/typebox").TObject<{
    contractVersion: import("@sinclair/typebox").TLiteral<"v1">;
    sequence: import("@sinclair/typebox").TInteger;
    eventKind: import("@sinclair/typebox").TString;
    schemaVersion: import("@sinclair/typebox").TInteger;
    workspaceId: import("@sinclair/typebox").TUnsafe<string>;
    aggregateId: import("@sinclair/typebox").TUnsafe<string>;
    aggregateRevision: import("@sinclair/typebox").TInteger;
    commandId: import("@sinclair/typebox").TUnsafe<string>;
    operationId: import("@sinclair/typebox").TOptional<import("@sinclair/typebox").TUnsafe<string>>;
    actor: import("@sinclair/typebox").TUnion<import("@sinclair/typebox").TLiteral<string>[]>;
    timestamp: import("@sinclair/typebox").TString;
    payload: import("@sinclair/typebox").TRecord<import("@sinclair/typebox").TString, import("@sinclair/typebox").TUnknown>;
}>];
//# sourceMappingURL=schemas.d.ts.map