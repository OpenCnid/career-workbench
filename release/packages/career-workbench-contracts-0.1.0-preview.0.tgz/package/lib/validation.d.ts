import { type Node } from "jsonc-parser";
import type { TSchema, Static } from "@sinclair/typebox";
export declare class ContractValidationError extends Error {
    readonly issues: readonly string[];
    constructor(message: string, issues: readonly string[]);
}
export declare function parseJsonWithoutDuplicateKeys(input: string): unknown;
export declare function decodeContract<T extends TSchema>(schema: T, input: unknown): Static<T>;
export declare function parseContract<T extends TSchema>(schema: T, input: string): Static<T>;
export type JsonNode = Node;
//# sourceMappingURL=validation.d.ts.map