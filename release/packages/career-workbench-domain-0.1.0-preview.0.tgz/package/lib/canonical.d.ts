export declare function canonicalJson(value: unknown): string;
//# sourceMappingURL=canonical.d.ts.map