export type DomainErrorCode = "invalid_request" | "unsupported_contract_version" | "workspace_not_found" | "workspace_unsafe" | "entity_not_found" | "revision_conflict" | "duplicate_identity" | "invalid_transition" | "evidence_unsupported" | "evidence_locator_invalid" | "artifact_unsealed" | "artifact_limit_exceeded" | "approval_required" | "approval_stale" | "approval_denied" | "capability_unavailable" | "model_unsupported" | "reasoning_unsupported" | "operation_canceled" | "operation_indeterminate" | "import_unsupported" | "external_content_rejected" | "internal_error";
export declare class DomainError extends Error {
    readonly code: DomainErrorCode;
    readonly retryable: boolean;
    readonly details?: Readonly<Record<string, unknown>> | undefined;
    constructor(code: DomainErrorCode, message: string, retryable?: boolean, details?: Readonly<Record<string, unknown>> | undefined);
}
export declare function assertDomain(condition: unknown, code: DomainErrorCode, message: string, details?: Readonly<Record<string, unknown>>): asserts condition;
//# sourceMappingURL=errors.d.ts.map