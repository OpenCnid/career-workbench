import type { EvidenceItem, ProfileFact, SourceDocument, SourceLocator } from "./entities.js";
export type FactConfirmationOutcome = {
    readonly kind: "confirm";
} | {
    readonly kind: "correct";
    readonly value: ProfileFact["value"];
    readonly locator: SourceLocator;
} | {
    readonly kind: "narrative_only";
} | {
    readonly kind: "cannot_confirm";
};
export declare function renderProfileFactClaim(fact: Pick<ProfileFact, "subject" | "predicate" | "value">): string;
/**
 * Stable rejection identity for an evidence assertion. Source bytes, rather
 * than generated entity IDs, prevent a recaptured copy from reviving a
 * rejected claim. A genuinely different source or locator remains distinct.
 */
export declare function evidenceRejectionIdentity(evidence: Pick<EvidenceItem, "claim" | "sourceId" | "locator">, source: SourceDocument | null): string;
export declare function validateSourceLocator(source: SourceDocument, locator: SourceLocator): void;
export declare function validateEvidenceForAcceptance(evidence: EvidenceItem, source: SourceDocument | null, candidateFact: ProfileFact | null): void;
//# sourceMappingURL=evidence.d.ts.map