import type { DimensionInput, DimensionScore, EntityId, EvidenceItem, Rubric } from "./entities.js";
export interface ScoreResult {
    readonly dimensionScores: readonly DimensionScore[];
    readonly aggregateScoreBasisPoints: number;
    readonly displayScore: string;
    readonly arithmeticExplanation: string;
    readonly gaps: readonly string[];
    readonly criticalFindings: readonly string[];
    readonly acceptedEvidenceIds: readonly EntityId[];
}
export declare function validateRubric(rubric: Rubric): void;
export declare function calculateScore(rubric: Rubric, inputs: readonly DimensionInput[], evidence: readonly EvidenceItem[]): ScoreResult;
//# sourceMappingURL=scoring.d.ts.map