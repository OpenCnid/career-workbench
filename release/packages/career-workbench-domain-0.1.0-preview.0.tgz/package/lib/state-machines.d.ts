import type { ApprovalState, ApplicationState, EvaluationState, OperationState } from "./entities.js";
export declare function requireApplicationTransition(from: ApplicationState, to: ApplicationState): void;
export declare function requireEvaluationTransition(from: EvaluationState, to: EvaluationState): void;
export declare function requireOperationTransition(from: OperationState, to: OperationState): void;
export declare function requireApprovalTransition(from: ApprovalState, to: ApprovalState): void;
export declare const APPLICATION_TRANSITIONS: Readonly<Record<ApplicationState, readonly ApplicationState[]>>;
export declare const EVALUATION_TRANSITIONS: Readonly<Record<EvaluationState, readonly EvaluationState[]>>;
export declare const OPERATION_TRANSITIONS: Readonly<Record<OperationState, readonly OperationState[]>>;
export declare const APPROVAL_TRANSITIONS: Readonly<Record<ApprovalState, readonly ApprovalState[]>>;
//# sourceMappingURL=state-machines.d.ts.map