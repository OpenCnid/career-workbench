import type { Context } from "@deepseek-ai/cordis";
import type { ToolDefinition, ToolRunContext } from "@deepseek-ai/dsh-tools";
import type { OperationAuthorities } from "./tools.js";
export interface NativeChildConfig {
    readonly provider?: string;
    readonly maxConcurrentChildren?: number;
    readonly maxDepth?: number;
    readonly defaultTimeoutMs?: number;
}
export declare class NativeChildCoordinator {
    private readonly ctx;
    private readonly owners;
    private readonly config;
    private readonly byOperation;
    private readonly byChild;
    private sequence;
    constructor(ctx: Context, owners: OperationAuthorities, config?: NativeChildConfig);
    private command;
    private activeFor;
    private loadOperation;
    private resolveDelegatingParent;
    private entryForParent;
    private queueSettlement;
    private settle;
    private armTimeout;
    start(args: unknown, exec: ToolRunContext): Promise<Readonly<Record<string, unknown>>>;
    followup(args: unknown, exec: ToolRunContext): Promise<Readonly<Record<string, unknown>>>;
    report(args: unknown, exec: ToolRunContext): Promise<Readonly<Record<string, unknown>>>;
    cancel(args: unknown, exec: ToolRunContext): Promise<Readonly<Record<string, unknown>>>;
    delete(args: unknown, exec: ToolRunContext): Promise<Readonly<Record<string, unknown>>>;
    status(args: unknown, exec: ToolRunContext): Promise<Readonly<Record<string, unknown>>>;
}
export declare const CHILD_TOOL_NAMES: readonly ["career_workbench_start_child", "career_workbench_child_status", "career_workbench_child_followup", "career_workbench_child_report", "career_workbench_cancel_child", "career_workbench_delete_child"];
export declare function createNativeChildTools(coordinator: NativeChildCoordinator): readonly ToolDefinition[];
//# sourceMappingURL=children.d.ts.map