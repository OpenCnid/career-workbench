import type { Context } from "@deepseek-ai/cordis";
import { CareerWorkbenchService, type AgentAuthority, type ChildOperationActivity, type ChildOperationAdmission, type ChildOperationTerminal, type ComparisonProjection, type ComparisonProposalCommand, type ComparisonResult, type CompleteEvaluationCommand, type EvaluationResult, type EvidenceProposal, type ProposeEvidenceCommand, type StartedOperation, type WorkbenchContext } from "./service.js";
export interface SupportedModel {
    readonly provider: string;
    readonly model: string;
    readonly reasoningEfforts: readonly string[];
}
export interface HttpProviderConfig {
    readonly baseUrl?: string;
    readonly serviceToken: string;
    readonly timeoutMs?: number;
    readonly supportedModels: readonly SupportedModel[];
}
export declare class HttpCareerWorkbenchService extends CareerWorkbenchService {
    private readonly config;
    private readonly baseUrl;
    private readonly timeoutMs;
    constructor(ctx: Context, config: HttpProviderConfig);
    private assertSelection;
    private request;
    readiness(authority: AgentAuthority, signal: AbortSignal): Promise<void>;
    context(authority: AgentAuthority, opportunityId: string | undefined, signal: AbortSignal): Promise<WorkbenchContext>;
    startEvaluation(authority: AgentAuthority, opportunityId: string, commandIdentity: string, signal: AbortSignal): Promise<StartedOperation>;
    comparisonProjections(authority: AgentAuthority, evaluationIds: readonly string[], commandIdentity: string, signal: AbortSignal): Promise<readonly ComparisonProjection[]>;
    startRlmComparison(authority: AgentAuthority, evaluationIds: readonly string[], commandIdentity: string, signal: AbortSignal): Promise<StartedOperation>;
    proposeComparison(authority: AgentAuthority, operationId: string, command: ComparisonProposalCommand, commandIdentity: string, signal: AbortSignal): Promise<ComparisonResult>;
    recordOperationActivity(authority: AgentAuthority, operationId: string, input: ChildOperationActivity, commandIdentity: string, signal: AbortSignal): Promise<StartedOperation>;
    settleOperation(authority: AgentAuthority, operationId: string, input: ChildOperationTerminal, commandIdentity: string, signal: AbortSignal): Promise<StartedOperation>;
    admitChildOperation(authority: AgentAuthority, input: ChildOperationAdmission, commandIdentity: string, signal: AbortSignal): Promise<StartedOperation>;
    recordChildActivity(authority: AgentAuthority, operationId: string, input: ChildOperationActivity, commandIdentity: string, signal: AbortSignal): Promise<StartedOperation>;
    settleChildOperation(authority: AgentAuthority, operationId: string, input: ChildOperationTerminal, commandIdentity: string, signal: AbortSignal): Promise<StartedOperation>;
    requestChildCancellation(authority: AgentAuthority, operationId: string, expectedRevision: number, reason: string, commandIdentity: string, signal: AbortSignal): Promise<StartedOperation>;
    proposeEvidence(authority: AgentAuthority, operationId: string, command: ProposeEvidenceCommand, commandIdentity: string, signal: AbortSignal): Promise<EvidenceProposal>;
    decideEvidence(authority: AgentAuthority, operationId: string, evidenceId: string, expectedRevision: number, decision: "accepted" | "rejected", reason: string, commandIdentity: string, signal: AbortSignal): Promise<EvidenceProposal>;
    completeEvaluation(authority: AgentAuthority, operationId: string, command: CompleteEvaluationCommand, commandIdentity: string, signal: AbortSignal): Promise<EvaluationResult>;
}
export declare const name = "career-workbench-http-provider";
export declare function apply(ctx: Context, config: HttpProviderConfig): void;
export default HttpCareerWorkbenchService;
//# sourceMappingURL=http-provider.d.ts.map