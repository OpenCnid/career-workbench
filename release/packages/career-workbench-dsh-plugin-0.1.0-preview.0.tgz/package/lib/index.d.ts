import type { Context } from "@deepseek-ai/cordis";
import "./dsh-projection-compat.js";
import { type NativeChildConfig } from "./children.js";
export * from "./children.js";
export * from "./http-provider.js";
export * from "./rlm.js";
export * from "./service.js";
export { TOOL_NAMES } from "./tools.js";
/** Exact DeepSeek Harness source revision inspected for this adapter. */
export declare const DSH_COMPATIBILITY_REVISION: "dd6322d604e00eec1ba5e0c8541159906a21094a";
/** Stable Cordis plugin name. */
export declare const name = "career-workbench-tools";
/** Public DSH services required by the plugin. */
export declare const inject: string[];
export type Config = NativeChildConfig;
/** Register native DSH tools and their security-critical prompt guidance. */
export declare function apply(ctx: Context, config?: Config): void;
/** Public manifest helper for installation diagnostics. */
export declare const manifest: {
    readonly name: "career-workbench-tools";
    readonly revision: "dd6322d604e00eec1ba5e0c8541159906a21094a";
    readonly tools: readonly ["career_workbench_inspect", "career_workbench_start_evaluation", "career_workbench_propose_evidence", "career_workbench_decide_evidence", "career_workbench_complete_evaluation", "career_workbench_start_child", "career_workbench_child_status", "career_workbench_child_followup", "career_workbench_child_report", "career_workbench_cancel_child", "career_workbench_delete_child", "career_workbench_start_comparison", "career_workbench_comparison_inputs", "career_workbench_propose_comparison", "career_workbench_rlm_snapshot", "career_workbench_rlm_restart", "career_workbench_rlm_status"];
};
//# sourceMappingURL=index.d.ts.map