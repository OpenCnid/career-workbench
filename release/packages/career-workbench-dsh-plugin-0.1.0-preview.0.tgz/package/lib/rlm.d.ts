import type { Context } from "@deepseek-ai/cordis";
import type { ToolDefinition, ToolRunContext } from "@deepseek-ai/dsh-tools";
import { type OperationAuthorities } from "./tools.js";
export declare const RLM_TOOL_NAMES: readonly ["career_workbench_start_comparison", "career_workbench_comparison_inputs", "career_workbench_propose_comparison", "career_workbench_rlm_snapshot", "career_workbench_rlm_restart", "career_workbench_rlm_status"];
export declare class NativeRlmCoordinator {
    private readonly ctx;
    private readonly owners;
    private readonly byOperation;
    private readonly bySession;
    constructor(ctx: Context, owners: OperationAuthorities);
    private onKernel;
    private queueActivity;
    private entry;
    start(args: unknown, exec: ToolRunContext): Promise<Record<string, unknown>>;
    inputs(args: unknown, exec: ToolRunContext): Promise<Record<string, unknown>>;
    propose(args: unknown, exec: ToolRunContext): Promise<Record<string, unknown>>;
    snapshot(args: unknown, exec: ToolRunContext): Promise<Record<string, unknown>>;
    restart(args: unknown, exec: ToolRunContext): Promise<Record<string, unknown>>;
    status(args: unknown, exec: ToolRunContext): Record<string, unknown>;
}
export declare function createRlmTools(coordinator: NativeRlmCoordinator): readonly ToolDefinition[];
//# sourceMappingURL=rlm.d.ts.map