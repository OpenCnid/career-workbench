import type { Context } from "@deepseek-ai/cordis";
import type { Agent } from "@deepseek-ai/dsh-agent";
import type { ToolDefinition } from "@deepseek-ai/dsh-tools";
import { type AgentAuthority } from "./service.js";
export declare function agentAuthority(agent: Agent | undefined): AgentAuthority;
export declare class OperationAuthorities {
    private readonly owners;
    bind(operationId: string, agent: Agent): void;
    require(operationId: string, agent: Agent | undefined): AgentAuthority;
    exact(operationId: string, agent: Agent | undefined): Agent;
    ownedBy(operationId: string, agent: Agent | undefined): boolean;
    release(operationId: string, agent: Agent): void;
}
export declare const TOOL_NAMES: readonly ["career_workbench_inspect", "career_workbench_start_evaluation", "career_workbench_propose_evidence", "career_workbench_decide_evidence", "career_workbench_complete_evaluation", "career_workbench_capture_source", "career_workbench_inspect_source", "career_workbench_capture_opportunity", "career_workbench_inspect_opportunity", "career_workbench_inspect_evaluation", "career_workbench_cancel_evaluation", "career_workbench_record_gap", "career_workbench_inspect_application", "career_workbench_transition_application", "career_workbench_draft_artifact", "career_workbench_inspect_artifact", "career_workbench_inspect_operation", "career_workbench_start_discovery", "career_workbench_record_discovery", "career_workbench_complete_discovery"];
export declare function createCareerWorkbenchTools(ctx: Context, owners?: OperationAuthorities): readonly ToolDefinition[];
//# sourceMappingURL=tools.d.ts.map