import type { Context } from "@deepseek-ai/cordis";
import type { Agent } from "@deepseek-ai/dsh-agent";
import type { ToolDefinition } from "@deepseek-ai/dsh-tools";
import { type AgentAuthority } from "./service.js";
export declare function agentAuthority(agent: Agent | undefined): AgentAuthority;
export declare class OperationAuthorities {
    private readonly owners;
    bind(operationId: string, agent: Agent): void;
    require(operationId: string, agent: Agent | undefined): AgentAuthority;
    exact(operationId: string, agent: Agent | undefined): Agent;
    ownedBy(operationId: string, agent: Agent | undefined): boolean;
    release(operationId: string, agent: Agent): void;
}
export declare const TOOL_NAMES: readonly ["career_workbench_inspect", "career_workbench_start_evaluation", "career_workbench_propose_evidence", "career_workbench_decide_evidence", "career_workbench_complete_evaluation"];
export declare function createCareerWorkbenchTools(ctx: Context, owners?: OperationAuthorities): readonly ToolDefinition[];
//# sourceMappingURL=tools.d.ts.map