import type { DiagnosticsResponse } from "@career-workbench/contracts";
type UpstreamCompatibility = DiagnosticsResponse["compatibility"]["deepSeekHarness"];
type UpstreamIdentity = UpstreamCompatibility["expected"];
export interface CompatibilityResolutionOverrides {
    readonly node?: string;
    readonly pnpm?: string;
    readonly typescript?: string;
    readonly careerWorkbench?: string;
    readonly cordis?: string;
    readonly deepSeekHarness?: Partial<UpstreamIdentity>;
    readonly nativeRlm?: Partial<UpstreamIdentity>;
    readonly careerOps?: Partial<UpstreamIdentity>;
    readonly patchSha256?: Readonly<Record<string, string>>;
}
export declare function buildCompatibilityDiagnostics(overrides?: CompatibilityResolutionOverrides): Pick<DiagnosticsResponse, "runtimeVersions" | "compatibility">;
export declare const CAREER_WORKBENCH_VERSION = "0.1.0-preview.0";
export {};
//# sourceMappingURL=compatibility.d.ts.map