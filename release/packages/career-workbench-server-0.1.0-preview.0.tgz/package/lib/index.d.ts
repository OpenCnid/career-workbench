#!/usr/bin/env node
export declare const SERVER_VERSION: "0.1.0-preview.0";
export { createServer } from "./server.js";
//# sourceMappingURL=index.d.ts.map