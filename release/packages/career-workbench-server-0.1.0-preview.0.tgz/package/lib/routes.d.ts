import type { FastifyInstance } from "fastify";
import { type IdFactory } from "@career-workbench/application";
import { type Runtime } from "./server.js";
export declare function registerDomainRoutes(server: FastifyInstance, runtime: Runtime, ids: IdFactory): void;
//# sourceMappingURL=routes.d.ts.map