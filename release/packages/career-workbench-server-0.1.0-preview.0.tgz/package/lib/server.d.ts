import { type FastifyInstance, type FastifyRequest } from "fastify";
import { WorkbenchService, type IdFactory } from "@career-workbench/application";
import type { CareerOpsDiscovery } from "@career-workbench/career-ops-import";
import { DomainError, type CommandContext, type Workspace } from "@career-workbench/domain";
import { ContentAddressedArtifactStore, SqliteWorkspaceStore } from "@career-workbench/storage";
export interface ServerOptions {
    readonly workspaceRoot: string;
    readonly webRoot?: string;
    readonly csrfToken?: string;
    readonly dshToken?: string;
    readonly rlmEnabled?: boolean;
    readonly idFactory?: IdFactory;
}
export interface Runtime {
    store: SqliteWorkspaceStore | null;
    artifacts: ContentAddressedArtifactStore | null;
    service: WorkbenchService | null;
    workspace: Workspace | null;
    recentErrorCategories: DomainError["code"][];
    careerOpsPreviews: Map<string, {
        readonly sourceDirectory: string;
        readonly discovery: CareerOpsDiscovery;
        readonly expiresAt: number;
    }>;
}
export declare function commandContext(request: FastifyRequest, ids: IdFactory, suffix?: string): CommandContext;
export declare function dshSessionFor(request: FastifyRequest): string | null;
export declare function subcommand(base: CommandContext, ids: IdFactory, suffix: string): CommandContext;
export declare function requireService(runtime: Runtime): WorkbenchService;
export declare function requireStore(runtime: Runtime): SqliteWorkspaceStore;
export declare function createServer(options: ServerOptions): Promise<FastifyInstance>;
//# sourceMappingURL=server.d.ts.map