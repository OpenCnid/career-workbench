import type { FastifyInstance } from "fastify";
import { type Runtime } from "./server.js";
export declare function registerEventRoutes(server: FastifyInstance, runtime: Runtime): void;
//# sourceMappingURL=sse.d.ts.map