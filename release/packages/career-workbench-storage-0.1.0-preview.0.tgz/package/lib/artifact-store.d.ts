import { type Digest } from "@career-workbench/domain";
export interface SealedBytes {
    readonly contentDigest: Digest;
    readonly byteLength: number;
    readonly relativePath: string;
}
export declare class ContentAddressedArtifactStore {
    private readonly workspaceRoot;
    private readonly maximumBytes;
    constructor(workspaceRoot: string, maximumBytes?: number);
    initialize(): Promise<void>;
    seal(content: Uint8Array, mediaType: string): Promise<SealedBytes>;
    read(sealed: SealedBytes): Promise<Uint8Array>;
    cleanupStaging(): Promise<number>;
    relativeToWorkspace(path: string): string;
}
//# sourceMappingURL=artifact-store.d.ts.map