export declare function assertSafeWorkspaceRoot(candidate: string): Promise<string>;
export declare function resolveWorkspaceRelative(root: string, relativePath: string): string;
//# sourceMappingURL=path-safety.d.ts.map