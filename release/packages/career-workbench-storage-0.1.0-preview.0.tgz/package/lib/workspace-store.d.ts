import { type ActorClass, type Application, type Approval, type Artifact, type CommandContext, type Comparison, type DiscoveryLead, type DomainEvent, type EntityId, type Evaluation, type EvidenceItem, type ImportManifest, type Opportunity, type Operation, type ProfileFact, type Rubric, type SearchProfile, type SourceDocument, type UtcTimestamp, type Workspace, type WorkspaceId } from "@career-workbench/domain";
export type EntityKind = "workspace" | "source" | "profileFact" | "searchProfile" | "discoveryLead" | "opportunity" | "evidence" | "rubric" | "evaluation" | "comparison" | "application" | "importManifest" | "artifact" | "operation" | "approval";
export interface EntityByKind {
    workspace: Workspace;
    source: SourceDocument;
    profileFact: ProfileFact;
    searchProfile: SearchProfile;
    discoveryLead: DiscoveryLead;
    opportunity: Opportunity;
    evidence: EvidenceItem;
    rubric: Rubric;
    evaluation: Evaluation;
    comparison: Comparison;
    application: Application;
    importManifest: ImportManifest;
    artifact: Artifact;
    operation: Operation;
    approval: Approval;
}
type RecordEntity = EntityByKind[EntityKind];
export type Mutation = {
    readonly action: "insert";
    readonly kind: EntityKind;
    readonly entity: RecordEntity;
} | {
    readonly action: "update";
    readonly kind: EntityKind;
    readonly entity: RecordEntity;
    readonly expectedRevision: number;
};
export interface EventToAppend {
    readonly eventKind: string;
    readonly aggregateId: string;
    readonly aggregateRevision: number;
    readonly payload: Readonly<Record<string, unknown>>;
    readonly timestamp: UtcTimestamp;
    readonly actor: ActorClass;
    readonly operationId?: EntityId;
}
export interface CommitRequest<Result> {
    readonly workspaceId: WorkspaceId;
    readonly context: CommandContext;
    readonly command: unknown;
    readonly mutations: readonly Mutation[];
    readonly events: readonly EventToAppend[];
    readonly result: Result;
}
export interface WorkspaceHealth {
    readonly schemaVersion: number;
    readonly foreignKeys: boolean;
    readonly journalMode: string;
    readonly integrity: "ok" | "corrupt";
    readonly lastSequence: number;
}
export interface RestoreResult {
    readonly rollbackRelativePath: string;
    readonly store: SqliteWorkspaceStore;
}
/**
 * Restores a workspace-local SQLite backup after the server/store is closed.
 * The displaced database is preserved as a verified rollback backup.
 */
export declare function restoreWorkspaceBackup(root: string, label: string, timestamp: UtcTimestamp): Promise<RestoreResult>;
export declare class SqliteWorkspaceStore {
    readonly root: string;
    private readonly native;
    private readonly db;
    private constructor();
    static create(root: string, timestamp: UtcTimestamp): Promise<SqliteWorkspaceStore>;
    static open(root: string, timestamp: UtcTimestamp): Promise<SqliteWorkspaceStore>;
    commit<Result>(request: CommitRequest<Result>): Promise<Result>;
    private applyMutation;
    get<Kind extends EntityKind>(kind: Kind, id: string): Promise<EntityByKind[Kind]>;
    findWorkspace(): Promise<Workspace | null>;
    list<Kind extends EntityKind>(kind: Kind, workspaceId: WorkspaceId): Promise<EntityByKind[Kind][]>;
    eventsAfter(workspaceId: WorkspaceId, sequence: number, limit?: number): Promise<DomainEvent[]>;
    recentEvents(workspaceId: WorkspaceId, limit?: number): Promise<DomainEvent[]>;
    eventsBefore(workspaceId: WorkspaceId, sequence: number, limit?: number): Promise<DomainEvent[]>;
    health(): Promise<WorkspaceHealth>;
    backup(label: string): Promise<string>;
    normalizedExport(workspaceId: WorkspaceId): Promise<Readonly<Record<string, unknown>>>;
    close(): Promise<void>;
    readConfig(): Promise<string>;
}
export {};
//# sourceMappingURL=workspace-store.d.ts.map