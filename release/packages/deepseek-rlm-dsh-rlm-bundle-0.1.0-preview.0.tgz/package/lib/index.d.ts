/** Loader resource package: runtime behavior is contributed by the patch rows. */
export declare const bundleVersion = "0.1.0-preview.0";
//# sourceMappingURL=index.d.ts.map