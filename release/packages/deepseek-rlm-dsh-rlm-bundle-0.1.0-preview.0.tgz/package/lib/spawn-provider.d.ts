import { Service, type Context } from '@deepseek-ai/cordis';
import type { SubagentProvider } from '@deepseek-ai/dsh-subagent';
import { Config as SpawnProviderConfigSchema } from '@deepseek-ai/dsh-subagent-spawn-in-process';
import type { Config as SpawnProviderConfig } from '@deepseek-ai/dsh-subagent-spawn-in-process';
/** Hard-dependency service published only after the named spawn provider commits. */
export declare const RLM_SPAWN_READY_SERVICE = "rlmSpawnReady";
declare module '@deepseek-ai/cordis' {
    interface Context {
        rlmSpawnReady: RlmSpawnReady;
    }
}
/** Exact provider identity made available to bundle consumers after registration. */
export declare class RlmSpawnReady extends Service {
    readonly providerName: string;
    readonly provider: SubagentProvider;
    constructor(ctx: Context, providerName: string, provider: SubagentProvider);
}
export declare const name = "rlm-spawn-provider";
export declare const inject: string[];
export type Config = SpawnProviderConfig;
export declare const Config: typeof SpawnProviderConfigSchema;
/** Register the native DSH provider, then publish the bundle readiness edge. */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=spawn-provider.d.ts.map