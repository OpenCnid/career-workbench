interface ByteBudgetAcceptance {
    readonly text: string;
    readonly reportTruncation: boolean;
}
/** Shared UTF-8 byte budget for every rendered channel of one cell. */
export declare class ByteBudget {
    readonly maximumBytes: number;
    private remainingBytes;
    private truncationReported;
    constructor(maximumBytes: number);
    take(text: string): ByteBudgetAcceptance;
}
/** Append-only UTF-8 byte-capped text accumulator. */
export declare class ByteAccumulator {
    private value;
    private usedBytes;
    private truncated;
    private readonly budget;
    constructor(maximumBytesOrBudget: number | ByteBudget);
    /** Append as much complete UTF-8 text as fits and return the accepted fragment. */
    append(text: string): string;
    /** Render the retained text with an explicit truncation diagnostic. */
    render(): string;
    /** Retained UTF-8 bytes, excluding the diagnostic. */
    get bytes(): number;
}
export {};
//# sourceMappingURL=byte-buffer.d.ts.map