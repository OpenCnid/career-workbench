import z from '@deepseek-ai/schemastery';
export interface Config {
    python?: string;
    artifactRoot?: string;
    managedRuntimeRoot?: string;
    subagentProvider?: string;
    maxDepth?: number;
    maxConcurrentKernelBoots?: number;
    interruptGraceMs?: number;
    shutdownGraceMs?: number;
    hostRequestDrainMs?: number;
    maxOutputBytes?: number;
    envAllowlist?: string[];
    env?: Record<string, string>;
    shellPath?: string;
    commandPrefix?: string;
    snapshot?: {
        policy?: 'after-cell' | 'idle' | 'dispose';
        maxBytes?: number;
        maxVariableBytes?: number;
    };
    adapters?: {
        tools?: boolean;
        goals?: boolean;
        compaction?: boolean;
    };
}
export interface ResolvedConfig {
    readonly python?: string;
    readonly artifactRoot: string;
    readonly managedRuntimeRoot: string;
    readonly subagentProvider: string;
    readonly maxDepth: number;
    readonly maxConcurrentKernelBoots: number;
    readonly interruptGraceMs: number;
    readonly shutdownGraceMs: number;
    readonly hostRequestDrainMs: number;
    readonly maxOutputBytes: number;
    readonly envAllowlist: readonly string[];
    readonly env: Readonly<Record<string, string>>;
    readonly shellPath?: string;
    readonly commandPrefix?: string;
    readonly snapshot: {
        readonly policy: 'after-cell' | 'idle' | 'dispose';
        readonly maxBytes: number;
        readonly maxVariableBytes: number;
    };
    readonly adapters: {
        readonly tools: boolean;
        readonly goals: boolean;
        readonly compaction: boolean;
    };
}
export declare const ConfigSchema: z<Config>;
/** Resolve defaults and enforce constraints that Schemastery cannot express. */
export declare function resolveConfig(input?: Config): ResolvedConfig;
/** A kernel receives no ambient environment unless a deployment allowlists it. */
export declare function kernelEnvironment(config: ResolvedConfig): Record<string, string>;
//# sourceMappingURL=config.d.ts.map