import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { type KernelHostRequestContext } from './kernel.js';
import type { ResolvedConfig } from './config.js';
type JsonObject = Readonly<Record<string, unknown>>;
/** Translation only: DSH remains the sole owner of agents, models, tools and policy. */
export declare class HostBridge {
    private readonly ctx;
    private readonly config;
    private readonly labelLock;
    constructor(ctx: Context, config: ResolvedConfig);
    dispatch(agent: Agent, type: string, payload: JsonObject, request: KernelHostRequestContext): Promise<JsonObject>;
    private route;
    private selectModel;
    private run;
    private findModels;
    private children;
    private listSubagents;
    private resolveChild;
    private deleteSubagent;
    private listAgents;
    private sendMessage;
    private listTools;
    private callTool;
}
export {};
//# sourceMappingURL=host.d.ts.map