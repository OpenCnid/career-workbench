import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import RlmRuntime, { type RlmExecuteRequest, type RlmExecutionResult, type RlmKernelInfo, type RlmSnapshotResult } from '@deepseek-rlm/dsh-rlm';
import { ConfigSchema, type Config } from './config.js';
export { ConfigSchema as Config };
export type { Config as JupyterRlmConfig };
export { HostRequestError } from './kernel.js';
export * from './protocol.js';
export * from './snapshot.js';
/** Persistent Jupyter provider; it never creates or drives a model loop. */
export declare class JupyterRlmRuntime extends RlmRuntime {
    static inject: string[];
    static Config: import("@deepseek-ai/schemastery").default<Config>;
    private readonly config;
    private readonly slots;
    private readonly attached;
    private readonly boots;
    private readonly bridge;
    private readonly predecessor;
    private readonly releaseFence;
    private disposed;
    constructor(ctx: Context, config?: Config);
    private attach;
    private assertAgent;
    private slot;
    private emit;
    private environment;
    private ensureReady;
    private startGeneration;
    private restore;
    execute(request: RlmExecuteRequest): Promise<RlmExecutionResult>;
    info(agent: Agent): RlmKernelInfo | undefined;
    private captureSnapshot;
    snapshot(agent: Agent, signal?: AbortSignal): Promise<RlmSnapshotResult | undefined>;
    restart(agent: Agent, signal?: AbortSignal): Promise<void>;
    disposeAgent(agent: Agent): Promise<void>;
    private disposeAll;
    /** Give an agent-owned cancellation a bounded opportunity to settle its outer cell before snapshot. */
    private waitForQuiescentCalls;
}
export default JupyterRlmRuntime;
//# sourceMappingURL=index.d.ts.map