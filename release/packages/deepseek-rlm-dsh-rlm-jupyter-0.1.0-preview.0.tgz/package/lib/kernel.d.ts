export declare const HOST_REQUEST_TARGET = "host.request";
/** Stable coded failure returned to the Python shim. */
export declare class HostRequestError extends Error {
    readonly code: string;
    constructor(message: string, code: string, options?: ErrorOptions);
}
/** Authority and cancellation supplied to one authenticated comm request. */
export interface KernelHostRequestContext {
    readonly requestId: string;
    readonly generation: number;
    readonly signal: AbortSignal;
    readonly execution: {
        readonly callId: string;
        readonly token?: symbol;
        readonly signal: AbortSignal;
        readonly isOpen: () => boolean;
        readonly nextNestedCallSequence: () => number;
    } | undefined;
    isCurrent(): boolean;
}
/** Host dispatcher. Payload excludes the request's routing `type` field. */
export type KernelHostRequestDispatcher = (type: string, payload: Readonly<Record<string, unknown>>, context: KernelHostRequestContext) => Promise<Readonly<Record<string, unknown>>>;
/** Inputs for one ordinary or provider-internal cell. */
export interface KernelExecuteOptions {
    readonly signal?: AbortSignal;
    readonly maxOutputBytes: number;
    readonly internal?: boolean;
    readonly callId?: string;
    readonly executionToken?: symbol;
    readonly onOutput?: (channel: 'stdout' | 'stderr', text: string) => void;
}
/** Raw settled cell result before the RLM service adds generation metadata. */
export interface KernelExecutionResult {
    readonly status: 'ok' | 'error' | 'aborted';
    readonly stdout: string;
    readonly stderr: string;
    readonly result?: string;
    readonly durationMs: number;
    readonly kernelRestarted: boolean;
    readonly error?: {
        readonly name: string;
        readonly message: string;
        readonly traceback: readonly string[];
    };
}
/** Configuration already resolved and validated by the Cordis provider. */
export interface KernelManagerOptions {
    readonly python: string;
    readonly cwd: string;
    readonly env: Readonly<Record<string, string>>;
    readonly sessionId: string;
    readonly generation: number;
    readonly interruptGraceMs: number;
    readonly shutdownGraceMs: number;
    readonly hostRequestDrainMs: number;
    readonly dispatchHostRequest: KernelHostRequestDispatcher;
    readonly isGenerationCurrent: () => boolean;
    readonly onPhase: (phase: 'start' | 'ready' | 'busy' | 'idle' | 'interrupt' | 'stop', fields?: {
        durationMs?: number;
        forced?: boolean;
    }) => void;
}
/** One kernel generation. A retired instance is never restarted in place. */
export declare class KernelManager {
    private readonly options;
    private readonly wireSession;
    private readonly generationAbort;
    private readonly commTargets;
    private readonly handledComms;
    private readonly requestTasks;
    private process;
    private connection;
    private connectionDirectory;
    private shell;
    private iopub;
    private control;
    private iopubPump;
    private startup;
    private executionTail;
    private active;
    private diagnostics;
    private state;
    constructor(options: KernelManagerOptions);
    get isRunning(): boolean;
    get connectionPath(): string | undefined;
    /** Start transport once; a failed startup can be retried only by a new generation. */
    start(signal?: AbortSignal): Promise<void>;
    private startInner;
    private waitForConnection;
    private probeReady;
    /** Serialize one cell behind every earlier cell in this generation. */
    execute(code: string, options: KernelExecuteOptions): Promise<KernelExecutionResult>;
    private executeNow;
    private startIopubPump;
    private runIopubPump;
    private handleExecutionMessage;
    private finishExecution;
    private handleComm;
    private startHostRequest;
    private dispatchAndReply;
    private sendCommReply;
    private interrupt;
    private handleProcessFailure;
    /** Abort host requests, drain them for a bound, then stop the complete process tree. */
    dispose(): Promise<void>;
    private gracefulShutdown;
    private retire;
    private closeChannels;
    private removeConnectionDirectory;
}
//# sourceMappingURL=kernel.d.ts.map