/** Loopback-only Jupyter connection metadata. */
export interface JupyterConnectionInfo {
    readonly ip: '127.0.0.1';
    readonly transport: 'tcp';
    readonly shell_port: number;
    readonly iopub_port: number;
    readonly stdin_port: number;
    readonly control_port: number;
    readonly hb_port: number;
    readonly signature_scheme: 'hmac-sha256';
    readonly key: string;
    readonly kernel_name: 'python3';
}
/** JSON fields carried by one Jupyter wire message. */
export interface JupyterMessage {
    readonly header: {
        readonly msg_id: string;
        readonly session: string;
        readonly username: string;
        readonly date: string;
        readonly msg_type: string;
        readonly version: string;
    };
    readonly parent_header: Readonly<Record<string, unknown>>;
    readonly metadata: Readonly<Record<string, unknown>>;
    readonly content: Readonly<Record<string, unknown>>;
}
/** Create a unique connection record whose ports ipykernel will fill. */
export declare function createConnectionInfo(): JupyterConnectionInfo;
/** Validate a connection file read after ipykernel selected its ports. */
export declare function parseConnectionInfo(value: unknown): JupyterConnectionInfo | undefined;
/** Build a host-originated request with a fresh message id. */
export declare function createMessage(type: string, content: Readonly<Record<string, unknown>>, session: string, username?: string): JupyterMessage;
/** Encode and authenticate the four JSON frames of one Jupyter message. */
export declare function encodeMessage(message: JupyterMessage, key: string): Buffer[];
/** Decode one authenticated multipart message; malformed or forged input is rejected. */
export declare function decodeMessage(incomingFrames: readonly Uint8Array[], key: string): JupyterMessage | undefined;
/** Narrow one wire value to a plain non-array record. */
export declare function isRecord(value: unknown): value is Record<string, unknown>;
//# sourceMappingURL=protocol.d.ts.map