/** Runtime assets copied to a path that Python build backends can address safely. */
interface StagedPythonRuntimeAssets {
    readonly primeRuntime: string;
    readonly dshRuntime: string;
    readonly requirementsLock: string;
}
/** Inputs for custom-interpreter probing or managed environment reuse. */
export interface PythonResolutionOptions {
    readonly python?: string;
    readonly managedRuntimeRoot: string;
    readonly probeEnvironment: Readonly<Record<string, string>>;
}
/**
 * Copy package-owned Python projects out of package-manager store paths before
 * asking a Python build backend to consume them. On Windows, hatchling can
 * misresolve project roots reached through pnpm virtual-store paths containing
 * scoped-package `+` segments and then report that a present `[project]` table
 * is missing. A short RLM-owned staging path also keeps the build independent
 * of symlink and package-manager layout details.
 */
export declare function stagePythonRuntimeAssets(assets: StagedPythonRuntimeAssets, destination: string): Promise<StagedPythonRuntimeAssets>;
/** Resolve a verified custom Python or an atomically provisioned Python 3.11 environment. */
export declare function resolveKernelPython(options: PythonResolutionOptions): Promise<string>;
/** Verify a configured root exists as a writable directory without retaining a probe file. */
export declare function verifyWritableDirectory(path: string): Promise<string>;
/** Return the parent directory, used by diagnostics without exposing environment values. */
export declare function runtimeParent(path: string): string;
export {};
//# sourceMappingURL=python.d.ts.map