/** Prime-compatible transformation for configured IPython `%%bash` cells. */
/** Apply a shell override and/or prefix only to a leading `%%bash` cell magic. */
export declare function applyShellSettings(code: string, options: {
    readonly commandPrefix?: string;
    readonly shellPath?: string;
    readonly requireExplicitShell?: boolean;
}): string;
//# sourceMappingURL=shell.d.ts.map