export declare const DEFAULT_SNAPSHOT_MAX_BYTES: number;
export declare const DEFAULT_SNAPSHOT_MAX_VARIABLE_BYTES: number;
/** Snapshot facts parsed from the helper marker. */
export interface SnapshotCapture {
    readonly saved: string[];
    readonly skipped: Array<{
        name: string;
        reason: string;
    }>;
    readonly bytes: number;
    readonly digest: string;
}
/** Per-name restore outcome parsed from the helper marker. */
export interface SnapshotRestore {
    readonly restored: string[];
    readonly failed: Array<{
        name: string;
        reason: string;
    }>;
}
export declare function snapshotPathIn(sessionDirectory: string): string;
export declare function manifestPathIn(sessionDirectory: string): string;
/** Build a bounded, best-effort, atomic namespace snapshot cell. */
export declare function buildSnapshotCode(outputPath: string, manifestPath: string, maximumBytes: number, maximumVariableBytes: number, runtimeVersion: string): string;
/** Build a per-name restore cell. Historical cells are never replayed. */
export declare function buildRestoreCode(inputPath: string): string;
export declare function parseSnapshotCapture(stdout: string): SnapshotCapture | undefined;
export declare function parseSnapshotRestore(stdout: string): SnapshotRestore | undefined;
//# sourceMappingURL=snapshot.d.ts.map