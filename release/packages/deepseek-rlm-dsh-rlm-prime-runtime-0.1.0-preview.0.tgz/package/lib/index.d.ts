/** Pinned Prime Agent revision represented by the staged runtime. */
export declare const PRIME_AGENT_REVISION = "f8f0036cc2da1a640aad990ae8dcb7c4820ce32e";
/** Pinned Python shim version. */
export declare const PRIME_RUNTIME_VERSION = "0.1.0";
/** DSH host-bridge protocol version. */
export declare const DSH_RLM_BRIDGE_PROTOCOL_VERSION = 1;
/** Absolute source directories installed into the managed Python environment. */
export interface PythonRuntimeAssets {
    readonly primeRuntime: string;
    readonly dshRuntime: string;
    readonly requirementsLock: string;
}
/**
 * Locate packaged assets, with a source-workspace fallback used before the package is built.
 * @returns absolute paths to both local Python projects.
 */
export declare function resolvePythonRuntimeAssets(): Promise<PythonRuntimeAssets>;
//# sourceMappingURL=index.d.ts.map